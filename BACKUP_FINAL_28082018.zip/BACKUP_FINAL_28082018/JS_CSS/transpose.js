$(function () {
            initialize
            if (!$("#table1").is(":blk-transpose"))
            $("#table1").transpose({ mode: 0 });
            });
            $("#btnTpVertical").click(function () {
            var currentMode = $("#table1").data("tp_mode");
            if (currentMode == undefined) {
            $("#table1").transpose("transpose");
            $("#btnTpVertical").html("reset");
            }
            else {
            $("#table1").transpose("reset");
            $("#btnTpVertical").html("transpose");
            }
            });
