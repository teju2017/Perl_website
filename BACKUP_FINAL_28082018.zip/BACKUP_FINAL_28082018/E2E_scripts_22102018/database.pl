#!/sbcimp/run/pd/csm/64-bit/perl/5.16.3/bin/perl

#######################################################################
# Script name  : database.pl
# Author       : Thejas HM
# Creatio dt   : 01-JUN-2018
# Description  : Handling the data insertion part of the RM 
#                onboarding portal
#######################################################################

use lib qw(
/opt/apache24/lib
/sbclocal/gdmp/lib/perl/
/sbcimp/run/pd/csm/64-bit/cpan/5.16.3-2013.03/lib
);

#MYG  End  Tag - GERA EOL

use CGI;
use DBI;
use DBD::Oracle;
use Data::Dumper;
use YAML;

$ENV{ORACLE_HOME}="/sbcimp/run/tp/oracle/client/v11.2.0.3-64bit/client_1";
$ENV{LD_LIBRARY_PATH}="/sbclocal/gdmp/lib";
$ENV{PERL5LIB}="/sbcimp/run/pkgs/CORE/15.1.0/lib";
$ENV{TNS_ADMIN}="/sbclocal/gdmp/etc";

my $rowmod;


################# SQL QUERY FORMATION ##########################


sub sql_formation()
{
   @columns=@_;


  $insert_statement="insert into onboarding_portal_table (CONSULTATION_ID,CONSULTATION_NAME,RM_SME,APPLICATION_CONTACT,BUSINESS_DIVISION,ISACID,ISAC_SOLUTION_NAME,CATEGORY,PRIORITY,REQUEST_ENTRYDATE,CONSULT_STARTDATE,PLANNED_CONSULT_STARTDT,PLANNED_CONSULT_ENDDATE,NUMBER_OF_FEEDS,TARGET_ARCHIVE,LOCATION,FOUR_EYE_PRINCIPLE,ESTIMATED_EFF,ACTUAL_EFF,PLANNED_ENDDATE,PLANNED_ONBOARDDATE,SERVICETYPE,CONSULTATION_REMARKS,CONSULTATION_STATUS,OBCONTACT,FEEDSDESCRIPTION,APPLICATION_IT_CONTACT,REQUEST_TYPE,LIST_ID,VERSION,ARCHIVE_ID,MANDATOR,TARGETSYSTEM,FORMAT,PLANNED_RELEASE,ACTUAL_RELEASE,BQLINK,TQLINK,PPMPROJECT,COSTOBJECT,ONBOARDSTATUS,ONBOARDINGREMARKS,OVERALLSTATUS,OVERALLREMARKS,SYSTEM_VERSION,EMAIL,MODIFICATION_DATE) values (";
    
   $counter=0;
   $length=@columns;
   
   &logwritter("length of array is $length");

   foreach $var (@columns)
   {
      $counter=$counter+1;
      if ( $counter == 1 )
      {
         $var1="consult_id_seq.nextval".",";
      }
      else
      {
         $var1=$var1."'".$var."'".",";
      }
   } 
   $sysdate="sysdate";
   $var1=$var1.$sysdate.")";
   $final_statement=$insert_statement." ".$var1;
   return $final_statement;
     
}


#############  LOG FILE WRITTER ##############################


sub logwritter()
{
    @msg=@_;
    #print "Value of msg is @msg \n";
    open(FH,'>>/sbclocal/gdmp/web/logs/E2E_LOGS.dat')||die "Cannot write into the file ";
    print FH @msg;
    print FH "\n";
    close(FH);
}


################## Data insertion method ###########################
sub data_insertion()
{
   $quy=@_[0];
   &logwritter("I AM INSIDE THE data_insertion now ");
   eval { 
   my $dbh = DBI->connect("dbi:Oracle:carmen","carmen","electra#1")|| &logwritter($DBI::errstr);
   $dbh->{AutoCommit}    = 1;
   $dbh->{RaiseError}    = 1;
   $dbh->{ora_check_sql} = 0;
   $dbh->{RowCacheSize}  = 16;
   $dbh->do("ALTER SESSION SET NLS_DATE_FORMAT='YYYY-MM-DD'");
   &logwritter("Just before the Prepare statement");
   &logwritter("Query value is $quy");
   my $sth = $dbh->prepare($quy);
   $sth->execute();
   $rowmod=$sth->rows();
   &logwritter("Executed the insert statement successfully and rowmod value is $rowmod");
   END {
       $dbh->disconnect if defined($dbh);
   }
   };
}


&logwritter("Paramter passed is @ARGV");
$insert_quy=&sql_formation(@ARGV);
&logwritter("value is $par_length");
&logwritter("Calling the data_insertion method");
&logwritter("Insert query method is $insert_quy");
#&data_insertion($insert_quy) || &logwritter("Error in the data_insertion method");
&data_insertion($insert_quy) && system('/sbclocal/gdmp/web/cgi-bin/E2E/E2E_scripts/message_display.pl',"DATA SUBMISSION SUCCESSFUL");
if ($@)
{
   &logwritter("Value of rowmod is $rowmod ");
   system('/sbclocal/gdmp/web/cgi-bin/E2E/E2E_scripts/message_display.pl',"DATA SUBMISSION FAILED, If you are using IE, make sure the data field is given in the YYYY-MM-DD format");
}
